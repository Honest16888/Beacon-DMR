# Beacon-DMR 远程更新推送系统

## 架构

```
┌─────────────────┐     GET /api/version      ┌──────────────────┐
│   Android App   │ ─────────────────────────→ │   Update Server  │
│  (web/index.html)│                            │  (update_server.py)│
│                 │     GET /api/download/ver  │                  │
│  Update.check() │ ─────────────────────────→ │  apks/*.apk      │
│  Update.download│ ←── APK 文件 ──────────────│  manifest.json   │
└─────────────────┘                            └──────────────────┘
```

## 部署步骤

### 1. 准备 APK 文件

```bash
mkdir -p apks
# 把构建好的 APK 放进去
cp beacon-dmr/dist/beacon-dmr-2.10.1-release.apk apks/
cp beacon-dmr/dist/beacon-dmr-2.10.0-release.apk apks/
```

### 2. 启动服务

```bash
python tools/update_server.py --port 8080 --apk-dir ./apks
```

服务启动后会自动扫描 `apks/` 目录，生成 `manifest.json`。

### 3. 配置客户端

在 Beacon-DMR App 的 **设置 → 更新服务器** 填入：
```
http://你的服务器IP:8080
```

或者用 Nginx 反代（推荐）：
```
https://update.你的域名.com
```

### 4. 发布新版本

```bash
# 1. 构建新 APK
bash tools/build_apk.sh release

# 2. 复制到 apks/ 目录
cp dist/beacon-dmr-2.10.2-release.apk apks/

# 3. 编辑 manifest.json 添加更新说明（可选）
#    服务端下次请求时会自动重新扫描
```

## API 接口

### 检查更新

```http
GET /api/version?current=2.10.0
```

响应：
```json
{
  "ok": true,
  "latest": "2.10.1",
  "has_update": true,
  "current": "2.10.0",
  "info": {
    "version": "2.10.1",
    "versionCode": 53,
    "size": 2308065,
    "sha256": "abc123...",
    "changelog": "修：长按排序被复制菜单抢走",
    "force": false,
    "minSdk": 26,
    "published": "2026-11-09T22:30:00Z",
    "download": "/api/download/2.10.1"
  }
}
```

### 下载 APK

```http
GET /api/download/2.10.1
```

支持 `Range` 头断点续传。

### 版本清单

```http
GET /api/manifest
```

## manifest.json 格式

```json
{
  "latest": "2.10.1",
  "versions": {
    "2.10.1": {
      "versionCode": 53,
      "apk": "beacon-dmr-2.10.1-release.apk",
      "size": 2308065,
      "sha256": "abc123...",
      "changelog": "更新说明（会显示在更新弹窗里）",
      "force": false,
      "minSdk": 26,
      "published": "2026-11-09T22:30:00Z"
    }
  }
}
```

**注意**：`manifest.json` 可以手动编辑，服务端不会覆盖你手写的 `changelog` 等字段。

## Nginx 配置（推荐）

```nginx
server {
    listen 443 ssl;
    server_name update.你的域名.com;

    ssl_certificate     /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;

        # APK 下载需要大文件支持
        proxy_buffering off;
        proxy_read_timeout 300;
    }
}
```

## 客户端行为

1. **启动后 3 秒**自动检查更新（不阻塞启动）
2. 设置页有 **「检查更新」** 按钮，可手动触发
3. 发现新版本弹窗提示，用户确认后下载
4. 下载完成后触发系统安装界面

## 强制更新

在 `manifest.json` 里把 `force` 设为 `true`，客户端会显示「此版本为强制更新」。

## 安全建议

- 生产环境用 **HTTPS**（Nginx + Let's Encrypt）
- `sha256` 字段用于客户端校验下载完整性
- 可以在 Nginx 层加 IP 白名单或 Basic Auth
